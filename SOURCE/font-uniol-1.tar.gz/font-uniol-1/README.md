# Uniol Unicode compliant Ol Chiki / Ol Cemet Font
This font design is taken from OlCHiki code page of unicode.org 
